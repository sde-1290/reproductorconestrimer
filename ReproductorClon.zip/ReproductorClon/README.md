# 🎵 ReproductorClon

Clon funcional de Apple Music hecho con Flutter. **Compilado y verificado**.

## ✅ Builds verificados

| Plataforma | Estado | Ubicación |
|------------|--------|-----------|
| 🌐 Web (release) | ✅ Compilado | `build/web/` (main.dart.js ~2.8 MB) |
| 🤖 Android APK (release) | ✅ Compilado | `build/app/outputs/flutter-apk/app-release.apk` (50.46 MB) |
| 📊 `flutter analyze` | ✅ 0 errores | Solo warnings de `withOpacity` deprecado y `const` |
| 🍎 iOS | ⚙️ Configurado | Requiere Xcode en macOS |

## 🎯 Características

- 🎵 **Reproductor de audio real** con `just_audio` (streaming HTTP)
- 🎨 **Tema oscuro** idéntico a Apple Music (color de acento `#FC3C44`)
- 📱 **Bottom navigation**: Inicio · Buscar · Biblioteca
- 🎼 **Mini player** persistente con barra de progreso
- 🎤 **Now Playing** completo:
  - Carátula grande con gradiente
  - Slider con seek
  - Play / pause / next / previous
  - Shuffle · Repeat (off / all / one)
  - Like · Download
- 🔍 **Búsqueda en vivo** (canciones, álbumes, artistas)
- 🎨 **Grid de géneros** con colores
- 📚 **Biblioteca con tabs**: Playlists · Álbumes · Artistas · Canciones
- ❤️ **Sistema Me gusta**
- 📲 **Detalles** de álbum, playlist y artista
- 🎬 **16 canciones** + **5 álbumes** + **6 playlists** + **6 artistas** de muestra
- 🎵 Audio desde SoundHelix (CC0) y portadas desde picsum.photos

## 🚀 Cómo usar

### Ver en navegador
```
flutter run -d chrome
```

### Compilar APK
```
flutter build apk --release
```
Genera `build/app/outputs/flutter-apk/app-release.apk`.

### Compilar Web
```
flutter build web --release
```
Genera `build/web/`. Abrir `build/web/index.html` en cualquier navegador moderno.

### Script interactivo (Windows)
Ejecuta `run.bat` o `run.ps1` desde la raíz del proyecto.

## 📁 Estructura

```
ReproductorClon/
├── lib/
│   ├── main.dart                     # Entry point + providers
│   ├── app.dart                      # MaterialApp + rutas (/album, /playlist, /artist)
│   ├── theme/app_theme.dart          # Tema dark estilo Apple Music
│   ├── models/                       # Song · Album · Artist · Playlist
│   ├── data/sample_data.dart         # 16 canciones, 5 álbumes, 6 artistas, 6 playlists
│   ├── providers/
│   │   ├── audio_provider.dart       # just_audio + queue + shuffle + repeat
│   │   └── library_provider.dart     # Library + búsqueda + likes + descargas
│   ├── screens/
│   │   ├── home_shell.dart           # Bottom nav + mini player
│   │   ├── home_screen.dart          # "Escuchar ahora" + Mezcla diaria
│   │   ├── search_screen.dart        # Búsqueda + grid de géneros
│   │   ├── library_screen.dart       # Tabs Playlists/Álbumes/Artistas/Canciones
│   │   ├── now_playing_screen.dart   # Reproductor fullscreen
│   │   ├── album_detail_screen.dart
│   │   ├── playlist_detail_screen.dart
│   │   ├── artist_detail_screen.dart
│   │   └── onboarding_screen.dart    # Pantalla de bienvenida
│   └── widgets/
│       ├── mini_player.dart          # Player compacto inferior
│       ├── song_tile.dart            # Fila de canción
│       ├── album_card.dart
│       ├── playlist_card.dart
│       └── artist_card.dart
├── android/                          # Configuración Android (Gradle 8.14, AGP 8.11.1, Kotlin 2.2.20)
├── ios/                              # Configuración iOS
├── web/                              # Plataforma web
└── test/widget_test.dart
```

**Total**: 24 archivos Dart · 124 archivos del proyecto.

## 🔧 Stack técnico

- **Flutter** 3.47.2 (stable)
- **Dart** 3.13.2
- **provider** ^6.1.1 — state management
- **just_audio** ^0.9.36 — reproducción de audio
- **google_fonts** ^6.1.0 — tipografía Inter
- **cached_network_image** ^3.3.0 — caché de imágenes

## 📝 Notas

- El audio se streamea desde `https://www.soundhelix.com/examples/mp3/`
- Las portadas se generan con seeds deterministas desde picsum.photos
- Compatible con Android 21+ (minSdk), compileSdk 34
- La ruta a Flutter SDK se detectó automáticamente vía `flutter create .`
